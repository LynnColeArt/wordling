package tui

import (
	"fmt"
	"strings"

	tea "charm.land/bubbletea/v2"
	"github.com/charmbracelet/x/ansi"
	"github.com/lynncoleart/wordling/internal/document"
	"github.com/lynncoleart/wordling/internal/editor"
	"github.com/lynncoleart/wordling/internal/input"
	"github.com/lynncoleart/wordling/internal/storage"
)

// CancelPendingMsg is an explicit host operation, never an original key alias.
// Disk IO continues; commands are held until the late receipt is reconciled.
type CancelPendingMsg struct{}

// RetryFirstReadMsg is explicit host safety, not an original-key alias.
// It cannot publish or acquire a replacement directory.
type RetryFirstReadMsg struct{}
type operation struct {
	id, revision uint64
	kind         editor.IntentKind
}
type Model struct {
	ascii             asciiQualification
	menu              menuDisplay
	runtime           *Runtime
	session           editor.Session
	width, height     int
	notice, reconcile string
	unsettled         []operation
	macro             *macroFlow
	macroTicket       *macroTicket
	macroCPU          bool
	macroStatus       MacroStatus
	macroFrozen       *macroPane
	repeatEntry       bool
	uiAuthority       *uiTransition
	macroDeferred     *macroIOReceipt
	firstPending      *firstTicket
}
type State struct {
	MenuBar          MenuBar
	RevealInspection RevealInspection

	Session                   editor.Snapshot
	Width, Height             int
	Notice, Reconciliation    string
	PendingIO                 int
	PhysicalDeliveryQualified bool
	Macro                     MacroStatus
	Profile                   string
	NativeProfile             string
}

func (m Model) State() State {
	profile := ""
	if m.runtime != nil {
		profile = m.runtime.profile
	}
	return State{MenuBar: m.menuState(), RevealInspection: m.inspectionState(), NativeProfile: NativeProfile, Profile: profile, Session: m.session.Snapshot(), Width: m.width, Height: m.height, Notice: m.notice, Reconciliation: m.reconcile, PendingIO: len(m.unsettled) + firstPendingCount(m.firstPending), Macro: m.macroStatus}
}

// Session returns an immutable value for measurements/inspection. Never fork it
// to execute independent intents: this Model owns the sole authoritative chain.
func (m Model) Session() editor.Session { return m.session }
func (m Model) Init() tea.Cmd           { return nil }
func (m Model) reduce(event editor.Event) (tea.Model, tea.Cmd) {
	previousMode := m.session.Snapshot().Mode
	next, intent, err := m.session.Reduce(event)
	m.session = next
	if err == nil && next.Snapshot().Mode == editor.MacroName && previousMode != editor.MacroName {
		m.macroStatus = MacroStatus{}
		m.macroFrozen = nil
	}
	m.notice = ""
	if err != nil {
		m.notice = err.Error()
	}
	if intent != nil {
		if firstKind(intent.Kind) {
			return m.queueFirst(*intent)
		}
		m.unsettled = append(append([]operation(nil), m.unsettled...), operation{intent.Operation, intent.Revision, intent.Kind})
		return m, m.runtime.command(*intent)
	}
	if next.Snapshot().Mode == editor.Exited {
		return m, tea.Quit
	}
	return m, nil
}
func (m Model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	if m.runtime == nil {
		m.notice = "Uninitialized host runtime"
		return m, nil
	}
	token, valid := m.runtime.claimUI(m.uiAuthority)
	if !valid {
		m.notice = "Stale UI transition refused; authentic model retains authority"
		return m, nil
	}
	m.uiAuthority = token
	next, cmd := m.update(msg)
	model := next.(Model)
	model.invalidateMenu()
	model.prepareASCIIViewport()
	return model, cmd
}
func (m Model) update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg.(type) {
	case firstReply, RetryFirstReadMsg, macroIOReply, macroReply, macroDuplicateMsg, macroReadRefusedMsg, HostStopMacroMsg, duplicateDispatchMsg, resultMsg, CancelPendingMsg:
		m.menu = menuDisplay{}
	}
	switch v := msg.(type) {
	case tea.EnvMsg, tea.ColorProfileMsg:
		// Bubble Tea startup administration is not delivered user input.
		return m, nil
	case firstReply:
		return m.firstResult(v.ticket)
	case RetryFirstReadMsg:
		if m.firstPending != nil || len(m.unsettled) > 0 || m.macro != nil {
			m.notice = "Actual IO still pending; Read retry refused"
			return m, nil
		}
		return m.reduce(editor.Event{Command: editor.RetryFirstRead})
	case macroIOReply:
		return m.macroIO(v.receipt)
	case macroReply:
		return m.macroReply(v)
	case macroDuplicateMsg:
		m.notice = "Duplicate macro dispatch refused; authentic continuation retained"
		return m, nil
	case macroReadRefusedMsg:
		return m.macroReadRefused(v)
	case HostStopMacroMsg:
		return m.hostStopMacro(v.Reason)
	}
	if _, ok := msg.(duplicateDispatchMsg); ok {
		m.notice = "Duplicate IO dispatch refused; no additional operation executed"
		return m, nil
	}
	if reply, ok := msg.(resultMsg); ok {
		result := reply.result
		if firstKind(result.Kind) {
			m.notice = "Unbound first-save payload refused; authentic receipt retained"
			return m, nil
		}
		if result.Kind == editor.ReadMacro {
			m.notice = "Unbound macro IO payload refused; authentic receipt retained"
			return m, nil
		}
		remaining := make([]operation, 0, len(m.unsettled))

		for _, op := range m.unsettled {
			if op == (operation{result.Operation, result.Revision, result.Kind}) {

			} else {
				remaining = append(remaining, op)
			}
		}
		m.unsettled = remaining
		if warning := Reconciliation(result); warning != "" {
			m.reconcile = warning
		}
		pending := m.session.Snapshot().Pending
		attached := pending != nil && pending.Operation == result.Operation && pending.Revision == result.Revision && pending.Kind == result.Kind
		if !attached && result.Err == nil && result.Outcome.State == storage.Published {
			m.reconcile = "Detached save published a destination; filesystem reconciliation required"
		}
		return m.reduce(editor.Event{Command: editor.Complete, Result: &result})
	}
	if _, ok := msg.(CancelPendingMsg); ok {
		return m.reduce(editor.Event{Command: editor.CancelOperation})
	}
	event := input.Translate(msg)
	if event.Kind == input.Resize {
		m.menu = menuDisplay{}
		m.width = max(1, min(event.Width, 4096))
		m.height = max(1, min(event.Height, 4096))
		return m, nil
	}
	if event.Kind != input.Press {
		switch event.Kind {
		case input.Paste, input.PasteStart, input.PasteEnd, input.Unknown:
			m.notice = "Unsupported event: " + string(event.Kind) + " (" + event.SourceType + ")"
		}
		return m, nil
	}
	m.invalidateMenu()
	if next, handled := m.menuPress(*event.Key); handled {
		return next, nil
	}
	if m.reconcile != "" {
		m.notice = "Resolve filesystem uncertainty before further commands"
		return m, nil
	}
	if (len(m.unsettled) > 0 || m.firstPending != nil) && m.session.Snapshot().Mode != editor.Waiting {
		m.notice = "Detached IO still pending; awaiting its actual receipt"
		return m, nil
	}
	k := event.Key
	if k.IsRepeat {
		m.notice = "Unsupported repeated key event"
		return m, nil
	}
	// Contextual Linux verification retry, not an original WP command claim.
	if k.Code == tea.KeyF10 && k.Mod == 0 && m.session.Snapshot().NewPhase == editor.PublishedUnbound {
		return m.reduce(editor.Event{Command: editor.RetryFirstRead})
	}
	if next, cmd, handled := m.macroKey(k.Code, k.Mod, k.Text); handled {
		return next, cmd
	}
	command, ok := resolve(*k, m.session.Snapshot().Mode)
	if !ok {
		m.notice = "Unsupported key (physical delivery unqualified)"
		return m, nil
	}
	return m.reduce(command)
}
func resolve(k input.Key, mode editor.Mode) (editor.Event, bool) {
	// Delivered text keeps its identity. No q/CtrlQ/CtrlS command aliases.
	if k.Mod&^(tea.ModShift|tea.ModCapsLock) == 0 && k.Text != "" {
		switch mode {
		case editor.RetrieveName, editor.SaveName, editor.MacroName, editor.Editing, editor.Waiting:
			return editor.Event{Command: editor.Text, Text: k.Text}, true
		case editor.ReplaceQuestion, editor.ExitSaveQuestion, editor.ExitQuestion, editor.DeleteQuestion:
			if k.Text == "y" || k.Text == "Y" {
				return editor.Event{Command: editor.Yes}, true
			}
			if k.Text == "n" || k.Text == "N" {
				return editor.Event{Command: editor.No}, true
			}
		case editor.HistoryPreview:
			if k.Text == "1" {
				return editor.Event{Command: editor.Restore}, true
			}
			if k.Text == "2" {
				return editor.Event{Command: editor.Previous}, true
			}
		}
	}
	event := editor.Event{}
	switch {
	case k.Code == tea.KeyF10 && k.Mod == tea.ModAlt:
		event.Command = editor.Macro
	case k.Code == tea.KeyF3 && k.Mod == tea.ModShift:
		event.Command = editor.SwitchDocument
	case k.Code == tea.KeyF10 && k.Mod == tea.ModShift:
		event.Command = editor.Retrieve
	case k.Code == tea.KeyF3 && k.Mod == tea.ModAlt:
		event.Command = editor.Reveal
	case k.Code == tea.KeyF4 && k.Mod == tea.ModAlt:
		event.Command = editor.Block
	case k.Mod != 0:
		return event, false
	default:
		switch k.Code {
		case tea.KeyF10:
			event.Command = editor.Save
		case tea.KeyF1:
			event.Command = editor.F1
		case tea.KeyF7:
			event.Command = editor.F7
		case tea.KeyEscape:
			event.Command = editor.Escape
		case tea.KeyHome:
			event.Command = editor.Home
		case tea.KeyUp:
			event.Command = editor.Up
		case tea.KeyRight:
			event.Command = editor.Right
		case tea.KeyLeft:
			event.Command = editor.Left
		case tea.KeyBackspace:
			event.Command = editor.Backspace
		case tea.KeyDelete:
			event.Command = editor.Delete
		case tea.KeyInsert:
			event.Command = editor.Insert
		case tea.KeyEnter:
			event.Command = editor.Enter
		default:
			return event, false
		}
	}
	return event, true
}

// panes uses only bounded authoritative document projections. It never interprets native bytes,
// wraps original pages, computes printed positions or serializes view text.
func (m Model) panes() (normal, reveal string, x int, err error) {
	f := m.visibleFrame()
	return f.normal, f.reveal, f.x, f.err
}
func (m Model) legacyPanes() (normal, reveal string, x int, err error) {
	d := m.session.Document()
	if d == nil {
		return "", "", 0, nil
	}
	s := m.session.Snapshot()
	gap := s.Gap
	if gap > document.MaxWindowTokens {
		return "", "", 0, fmt.Errorf("cursor beyond bounded %d-token presentation", document.MaxWindowTokens)
	}
	count := min(d.TokenCount(), document.MaxWindowTokens)
	p, err := m.session.Present(0, count)
	if err != nil {
		return "", "", 0, err
	}
	elements := p.Elements
	blockStart, blockEnd := -1, -1
	if s.Selection {
		blockStart, blockEnd = s.SelectionStart, s.SelectionEnd
	}
	if s.Mode == editor.HistoryPreview {
		info, e := m.session.Preview(0, 0)
		if e != nil {
			return "", "", 0, e
		}
		if info.TotalTokens > document.MaxWindowTokens {
			return "", "", 0, fmt.Errorf("preview exceeds bounded %d-token presentation", document.MaxWindowTokens)
		}
		overlay, e := m.session.Preview(0, info.TotalTokens)
		if e != nil {
			return "", "", 0, e
		}
		elements = make([]document.Element, len(overlay.Elements))
		for i, v := range overlay.Elements {
			elements[i] = document.Element{TokenIndex: i, Kind: v.Kind, Text: v.Text}
		}
		blockStart, blockEnd = overlay.FragmentStart, overlay.FragmentEnd
	}
	var n strings.Builder
	var lower []revealRun
	nativeActive := !s.Selection && s.Mode != editor.HistoryPreview
	nx, rx := 0, 0
	for i := 0; i <= len(elements); i++ {
		if i == blockStart {
			n.WriteString("[Block]")
			lower = append(lower, revealRun{text: "[Block]", role: revealBase})
			if i < gap {
				nx += 7
				rx += 7
			}
		}
		if i == blockEnd {
			n.WriteString("[Block]")
			lower = append(lower, revealRun{text: "[Block]", role: revealBase})
			if i < gap {
				nx += 7
				rx += 7
			}
		}
		if i == len(elements) {
			break
		}
		e := elements[i]
		rt := e.Text
		switch e.Kind {
		case document.BoldOn:
			n.WriteString("\x1b[1m")
			rt = "[BOLD]"
		case document.BoldOff:
			n.WriteString("\x1b[22m")
			rt = "[bold]"
		case document.ASCII:
			n.WriteString(e.Text)
			if i < gap {
				nx += len(e.Text)
			}
		default:
			return "", "", 0, fmt.Errorf("unsupported token presentation")
		}
		role := revealBase
		if e.Kind == document.BoldOn || e.Kind == document.BoldOff {
			role = revealCode
		}
		// Overlay elements deliberately have no native span. Only an element
		// returned by the authoritative native Present can own active cells.
		if nativeActive && e.TokenIndex == p.CursorGap && e.Span.Length > 0 {
			role = revealActive
		}
		lower = append(lower, revealRun{text: rt, role: role})
		if i < gap {
			rx += len(rt)
		}
	}
	if nativeActive && p.CursorGap == d.TokenCount() {
		lower = append(lower, revealRun{text: " ", role: revealActive})
	}
	// Terminal cell scrolling is view-only, never original pagination or Pos.
	ns, rs := max(0, nx-max(1, m.width/2)), max(0, rx-max(1, m.width/2))
	x = nx - ns
	return ansi.TruncateLeft(n.String()+"\x1b[0m", ns, ""), renderReveal(lower, rs, m.width), x, nil
}
func clip(s string, width int) string {
	out := ansi.Truncate(s, width, "")
	if strings.Contains(s, "\x1b[") {
		out += "\x1b[0m"
	}
	return out
}
func (m Model) View() tea.View {
	s := m.session.Snapshot()
	frame := m.visibleFrame()
	if frame.anchors {
		return m.anchorView(frame, s.Reveal)
	}
	normal, reveal, x, err := frame.normal, frame.reveal, frame.x, frame.err
	lines := []string{"Wordling 5.2 | bounded native editing", normal}
	if err != nil {
		lines[1] = "Unsupported document presentation: " + err.Error()
	}
	if s.Reveal {
		banner := "Press Reveal Codes to restore screen"
		if frame.inspection.Partial {
			banner = "Partial Reveal inspection | HOST ?N = unsupported owner"
		}
		lines = append(lines, banner, reveal)
	}
	prompt := s.Prompt
	if m.repeatEntry {
		prompt = "Repeat Value = "
	} else if s.Mode == editor.Editing && s.MacroRepeat == 3 {
		prompt = "Repeat Value = 3"
	}
	prompt = m.menuPrompt(s, prompt)
	lines = append(lines, prompt, s.Notice)
	if line := m.macroLine(); line != "" {
		lines = append(lines, line)
	}
	if s.Screen == 2 {
		lines = append(lines, "Doc2")
	}
	if line := firstStateLine(s); line != "" {
		lines = append(lines, line)
	}
	if s.Mode == editor.Waiting {
		lines = append(lines, "Filesystem operation pending")
	}
	if m.notice != "" {
		lines = append(lines, m.notice)
	}
	if m.reconcile != "" {
		lines = append(lines, m.reconcile)
	}
	history := "unknown"
	if s.HistoryCountKnown {
		history = fmt.Sprint(s.HistoryCount)
	}
	typing := ""
	if s.Typeover {
		typing = "Typeover "
	}
	profileLabel := "local-flat: ASCII basenames only; physical key delivery UNQUALIFIED"
	if m.runtime != nil && m.runtime.profile == MacroCOUT {
		profileLabel = "macro-cout: exact C:\\OUT\\ and flat names; physical key delivery UNQUALIFIED"
	}
	lines = append(lines, fmt.Sprintf("%s | %s | gap %d | %s", s.Mode, s.Name, s.Gap, s.SaveState),
		fmt.Sprintf("%sDirty=%t Block=%t revision=%d history=%s qualified=%t", typing, s.Dirty, s.Selection, s.Revision, history, s.HistoryQualified), profileLabel)
	if m.menuState().Visible {
		lines[0] = renderMenuBar()
	}
	for i := range lines {
		lines[i] = clip(lines[i], m.width)
	}
	if len(lines) > m.height {
		lines = lines[:m.height]
	}
	v := tea.NewView(strings.Join(lines, "\n"))
	v.AltScreen = true
	v.KeyboardEnhancements = tea.KeyboardEnhancements{ReportEventTypes: true, ReportAlternateKeys: true, ReportAllKeysAsEscapeCodes: true, ReportAssociatedText: true}
	if (s.Mode == editor.Editing || s.Mode == editor.DeleteQuestion || s.Mode == editor.HistoryPreview || s.Mode == editor.Waiting) && err == nil && m.height > 1 {
		y := 1
		if y < m.height {
			v.Cursor = tea.NewCursor(min(x, m.width-1), y)
		}
	}
	// Prompt caret refers to the original reducer draft, not document position.
	if (s.Mode == editor.RetrieveName || s.Mode == editor.SaveName || s.Mode == editor.MacroName) && len(lines) > 2 {
		prefix := "Document to be retrieved: "
		if s.Mode == editor.SaveName {
			prefix = "Document to be saved: "
		} else if s.Mode == editor.MacroName {
			prefix = "Macro: "
		}
		y := 2
		if s.Reveal {
			y = 4
		}
		if y < m.height {
			v.Cursor = tea.NewCursor(min(len(prefix)+s.Caret, m.width-1), y)
		}
	}
	if (m.repeatEntry || s.Mode == editor.Editing && s.MacroRepeat == 3) && m.height > 2 {
		x := len("Repeat Value = ")
		if !m.repeatEntry {
			x++
		}
		v.Cursor = tea.NewCursor(min(x, m.width-1), 2)
	}
	return v
}

// anchorEligible observes existing source/UI owners. It grants no command or IO
// authority. The pristine menu uses its qualified legacy base on BOTH toggles.
func (m Model) anchorEligible(s editor.Snapshot, frame macroPane) bool {
	if m.width != 80 || m.height != 25 || m.runtime == nil || frame.err != nil || frame.inspection.Partial ||
		s.Mode != editor.Editing || s.Selection || s.Typeover || !s.HistoryCountKnown || s.Screen != 1 || s.MacroRepeat != 1 ||
		s.Pending != nil || s.Prompt != "" || s.Notice != "" || m.repeatEntry || m.notice != "" || m.reconcile != "" ||
		len(m.unsettled) != 0 || m.firstPending != nil || m.macro != nil || m.macroTicket != nil || m.macroCPU ||
		m.macroDeferred != nil || m.macroStatus.Active || m.macroStatus.WorkerPending || m.macroStatus.DisplaySuppressed ||
		s.NewPhase == editor.PublishedUnbound || s.NewPhase == editor.PublicationUncertain ||
		m.menuReason() == "" || m.menu.diagnostic != "" {
		return false
	}
	m.runtime.mu.Lock()
	defer m.runtime.mu.Unlock()
	return !m.runtime.stopping && m.runtime.macro == nil && m.uiAuthority != nil && m.uiAuthority == m.runtime.uiAuthority
}

// A fixed bounded display composition, not original page/ruler/status layout.
// Frozen frames retain this choice even when later live state/size is different.
func (m Model) anchorView(frame macroPane, reveal bool) tea.View {
	lines := make([]string, 25)
	lines[0] = revealBase + frame.normal
	if reveal {
		lines[13] = frame.reveal
		lines[24] = renderReveal([]revealRun{
			{text: "Press ", role: revealBase},
			{text: "Reveal Codes", role: revealCode},
			{text: " to restore screen" + strings.Repeat(" ", 44), role: revealBase},
		}, 0, 80)
	}
	for i := range lines {
		lines[i] = clip(lines[i], m.width)
	}
	lines = lines[:min(len(lines), m.height)]
	v := tea.NewView(strings.Join(lines, "\n"))
	v.AltScreen = true
	v.KeyboardEnhancements = tea.KeyboardEnhancements{ReportEventTypes: true, ReportAlternateKeys: true, ReportAllKeysAsEscapeCodes: true, ReportAssociatedText: true}
	v.Cursor = tea.NewCursor(min(frame.x, m.width-1), 0)
	return v
}
