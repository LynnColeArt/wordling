// Package tui composes the approved native editing session with Bubble Tea and rooted IO.
package tui

import (
	"errors"
	"fmt"
	"path/filepath"
	"sync"

	tea "charm.land/bubbletea/v2"
	"github.com/lynncoleart/wordling/internal/editor"
	"github.com/lynncoleart/wordling/internal/storage"
)

const LocalFlat = "local-flat"

// MacroCOUT is an explicit host adaptation for immutable original macro names.
// Only this exact literal namespace and flat basenames share one opened root.
const MacroCOUT = "macro-cout"

// NativeProfile names the sole constructor profile selected inside approved47.
// It does not certify physical layout or supply proprietary printer resources.
const NativeProfile = "historical-us51-dos-text-standard-printer"

type Config struct{ Root, Profile, NativeProfile string }

// Runtime owns the pinned directory and worker lifetime. Close prevents new IO,
// waits for every started operation and closes only then. A queued Cmd invoked
// after Close returns an explicit refusal without touching closed descriptors.
// Completed returns copied receipts, including results Bubble Tea could not
// deliver during a host signal. A cancelled UI operation never cancels disk IO.
type Runtime struct {
	mu           sync.Mutex
	directory    *storage.Directory
	stopping     bool
	profile      string
	workers      sync.WaitGroup
	done         chan struct{}
	closeErr     error
	results      []editor.Result
	issued       int
	executed     map[operation]bool
	macro        *macroFlow
	macroResults []MacroOutcome
	uiAuthority  *uiTransition
	firstTickets map[editor.RequestKey]*firstTicket
}

func Open(config Config) (*Runtime, Model, error) {
	if config.NativeProfile != "" && config.NativeProfile != NativeProfile {
		return nil, Model{}, errors.New("unsupported native startup profile")
	}
	if (config.Profile != LocalFlat && config.Profile != MacroCOUT) || !filepath.IsAbs(config.Root) {
		return nil, Model{}, errors.New("require absolute -root and explicit -profile local-flat or macro-cout (operator-selected validated local filesystem; exact closed namespace only)")
	}
	d, err := storage.OpenDirectory(config.Root)
	if err != nil {
		return nil, Model{}, err
	}
	locations := []editor.Location{{Directory: d}}
	if config.Profile == MacroCOUT {
		locations = append(locations, editor.Location{Prefix: "C:\\OUT\\", Directory: d})
	}
	s, err := editor.New(editor.Config{Locations: locations})
	if err != nil {
		return nil, Model{}, errors.Join(err, d.Close())
	}
	r := &Runtime{directory: d, profile: config.Profile, uiAuthority: &uiTransition{1}, done: make(chan struct{}), executed: make(map[operation]bool), firstTickets: make(map[editor.RequestKey]*firstTicket)}
	return r, Model{runtime: r, uiAuthority: r.uiAuthority, session: s, width: 80, height: 25}, nil
}
func copyResult(r editor.Result) editor.Result {
	var failure *storage.Failure
	if r.Document != nil {
		v := *r.Document
		r.Document = &v
	}
	if r.Destination != nil {
		v := *r.Destination
		r.Destination = &v
	}
	if r.Macro != nil {
		v := *r.Macro
		r.Macro = &v
	}
	if !firstKind(r.Kind) && errors.As(r.Err, &failure) && failure != nil {
		f := *failure
		r.Err = &f
	}
	return r
}
func (r *Runtime) Completed() []editor.Result {
	r.mu.Lock()
	defer r.mu.Unlock()
	out := make([]editor.Result, len(r.results))
	for i, v := range r.results {
		out[i] = copyResult(v)
	}
	return out
}
func (r *Runtime) Close() error {
	r.mu.Lock()
	if r.stopping {
		done := r.done
		r.mu.Unlock()
		<-done
		r.mu.Lock()
		defer r.mu.Unlock()
		return r.closeErr
	}
	r.stopping = true
	if r.macro != nil {
		r.macro.closedByHost = true
		r.macro.cancel()
	}
	r.mu.Unlock()
	r.workers.Wait()
	r.mu.Lock()
	if r.macro != nil {
		r.recordMacroLocked(r.macro)
	}
	r.mu.Unlock()
	err := r.directory.Close()
	r.mu.Lock()
	r.closeErr = err
	close(r.done)
	r.mu.Unlock()
	return err
}

type resultMsg struct{ result editor.Result }

// duplicateDispatchMsg has no completion payload: this invocation did not own
// the admitted operation and cannot settle its pending UI/disk outcome.
type duplicateDispatchMsg struct{}

func (r *Runtime) command(request editor.Intent) tea.Cmd {
	// Capture all public wrappers and bytes before dispatch. Directory value
	// equality compares the one private opened capability (not wrapper address,
	// path or inode); an independent open of the same inode is not that lifetime.
	if request.Directory != nil {
		v := *request.Directory
		request.Directory = &v
	}
	if request.Document != nil {
		v := *request.Document
		request.Document = &v
	}
	if request.Destination != nil {
		v := *request.Destination
		request.Destination = &v
	}
	request.Candidate = append([]byte(nil), request.Candidate...)
	return func() tea.Msg {
		result := editor.Result{Operation: request.Operation, Revision: request.Revision, Kind: request.Kind}
		r.mu.Lock()
		key := operation{request.Operation, request.Revision, request.Kind}
		// Check admission before shutdown/capacity. Those guards also cannot
		// turn a second invocation into completion of an earlier admitted IO.
		if r.executed[key] {
			r.mu.Unlock()
			return duplicateDispatchMsg{}
		}
		if r.stopping {
			r.mu.Unlock()
			result.Err = errors.New("host IO is closed")
			if request.Kind == editor.ReadMacro {
				return macroReadRefusedMsg{request, result.Err}
			}
			return resultMsg{result}
		}
		if r.issued >= 1024 {
			r.mu.Unlock()
			result.Err = errors.New("host receipt safety limit reached (1024 operations); restart after checking filesystem outcomes")
			if request.Kind == editor.ReadMacro {
				return macroReadRefusedMsg{request, result.Err}
			}
			return resultMsg{result}
		}
		r.executed[key] = true
		r.issued++
		r.workers.Add(1)
		r.mu.Unlock()
		defer r.workers.Done()
		macroReadExecuted := false
		if request.Directory == nil || *request.Directory != *r.directory {
			result.Err = errors.New("foreign rooted directory intent")
		} else {
			switch request.Kind {
			case editor.ReadMacro:
				macroReadExecuted = true
				result = editor.ExecuteMacroRead(&request)
			case editor.Read:
				result.Document, result.Err = request.Directory.Read(request.Name)
			case editor.Observe:
				result.Destination, result.Err = request.Directory.Observe(request.Name)
			case editor.WriteSnapshot:
				result.Outcome, result.Err = request.Directory.Save(request.Document, request.Destination, request.Decision)
			case editor.PublishCandidate:
				id := storage.PublicationID{Operation: request.Operation, Revision: request.Revision}
				publication, err := request.Directory.PreparePublication(request.Document, request.Destination, request.Candidate, id)
				result.Err = err
				if err == nil {
					result.Outcome, result.Err = request.Directory.Publish(publication, id)
				}
			default:
				result.Err = fmt.Errorf("unsupported IO intent %q", request.Kind)
			}
		}
		r.mu.Lock()
		receipt := copyResult(result)
		// Shutdown receipts retain outcomes/errors, not entire native images.
		receipt.Document, receipt.Destination = nil, nil
		if request.Kind == editor.ReadMacro {
			// Construct a diagnostic receipt without retaining the private
			// acquisition proof/image hidden inside editor.Result.
			receipt = editor.Result{Operation: result.Operation, Revision: result.Revision, Kind: result.Kind, Err: copyResult(result).Err}
		}
		r.results = append(r.results, receipt)
		r.mu.Unlock()
		if request.Kind == editor.ReadMacro {
			if !macroReadExecuted {
				return macroReadRefusedMsg{request, result.Err}
			}
			return macroIOReply{&macroIOReceipt{owner: r, key: key, result: copyResult(result)}}
		}
		return resultMsg{result}
	}
}

// Reconciliation describes any outcome that must not be presented as clean
// exit/save. It does not remove residue or roll back an ambiguous destination.
func Reconciliation(result editor.Result) string {
	var f *storage.Failure
	if errors.As(result.Err, &f) && f != nil && (f.DestinationMayExist || f.Candidate != "") {
		return fmt.Sprintf("Filesystem reconciliation required: %v; candidate=%q; destination may exist=%t", result.Err, f.Candidate, f.DestinationMayExist)
	}
	if result.Err != nil && result.Outcome.State == storage.Published {
		return fmt.Sprintf("Filesystem reconciliation required: destination may exist after reported publication: %v", result.Err)
	}
	return ""
}
