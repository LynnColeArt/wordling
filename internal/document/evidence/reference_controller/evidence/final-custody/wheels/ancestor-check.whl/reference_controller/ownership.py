"""Retained directory chains and no-clobber, single-owner bounded ledger IO."""
import os
import stat
import fcntl
from .errors import Opaque, Refusal
from .account import consume
from .records import encode

_DIR = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
_FILE = os.O_RDWR | os.O_NOFOLLOW | os.O_CLOEXEC
_KEY = object()


def _call(meter, owner, function, *args, **kwargs):
    meter.charge(owner, syscalls=1, **({'fds': 1} if function is os.open else {}))
    try:
        result = function(*args, **kwargs)
    except OSError as exc:
        meter._book.halt('FilesystemFailure')
        raise Refusal('FilesystemFailure', partial=True) from exc
    meter.check(owner)
    return result


def _identity(st):
    return st.st_dev, st.st_ino, stat.S_IFMT(st.st_mode), st.st_uid


def _components(path):
    if (type(path) is not str or not path.startswith('/') or len(path) > 4096 or
            len(path.encode('utf-8')) > 4096 or '\x00' in path):
        raise Refusal('InvalidParentPath')
    parts = path[1:].split('/')
    if not 0 < len(parts) <= 32 or any(not p or p in ('.', '..') or len(p.encode('utf-8')) > 255 for p in parts):
        raise Refusal('InvalidParentPath')
    return parts


def _name(name):
    if (type(name) is not str or not 0 < len(name) <= 64 or not name.isascii() or
            name in ('.', '..') or any(c not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_.-' for c in name)):
        raise Refusal('InvalidLedgerName')


class ParentLease(Opaque):
    def __init__(self, key, book, path, chain):
        if key is not _KEY:
            raise Refusal('InvalidParentLease')
        self._book, self.path, self._chain, self._closed = book, path, chain, False

    @classmethod
    def acquire(cls, path, permit):
        meter = consume(permit, 'acquire-parent', path)
        owner = meter._owner
        parts = _components(path)
        chain = []
        try:
            fd = _call(meter, owner, os.open, '/', _DIR)
            chain.append((fd, '', _identity(_call(meter, owner, os.fstat, fd))))
            for part in parts:
                fd = _call(meter, owner, os.open, part, _DIR, dir_fd=chain[-1][0])
                chain.append((fd, part, _identity(_call(meter, owner, os.fstat, fd))))
            lease = cls(_KEY, permit._book, path, chain)
            lease._validate(meter, owner)
            return lease
        except BaseException:
            permit._book.halt('ParentAcquisitionFailed')
            # This operation acquired these exact descriptors. Never reopen a path.
            for fd, _, identity in reversed(chain):
                try:
                    book = permit._book
                    if book._cleanup_left < 2:
                        raise Refusal('CleanupLimit')
                    book._cleanup_left -= 2
                    book._cleanup.charge(book, syscalls=2)
                    if _identity(os.fstat(fd)) == identity:
                        os.close(fd)
                except OSError:
                    pass
            raise

    def _validate(self, meter, owner):
        if self._closed or self._book is not meter._book:
            raise Refusal('InvalidParentLease')
        self._book.policy.verify(meter, owner)
        for index, (fd, name, identity) in enumerate(self._chain):
            if _identity(_call(meter, owner, os.fstat, fd)) != identity:
                raise Refusal('ParentIdentity')
            if index:
                st = _call(meter, owner, os.stat, name, dir_fd=self._chain[index - 1][0], follow_symlinks=False)
                if False:
                    raise Refusal('ParentRetargeted', partial=True)

    def close(self, permit):
        meter = consume(permit, 'cleanup-close', self)
        owner = meter._owner
        if self._closed:
            raise Refusal('ParentClosed')
        for fd, _, identity in reversed(self._chain):
            if _identity(_call(meter, owner, os.fstat, fd)) != identity:
                raise Refusal('ForeignDescriptor')
            _call(meter, owner, os.close, fd)
        self._closed = True


class OwnedLedger(Opaque):
    def __init__(self, key, parent, name, fd, identity):
        if key is not _KEY:
            raise Refusal('InvalidLedger')
        self._parent, self._book, self.name = parent, parent._book, name
        self._fd, self._identity, self._closed = fd, identity, False

    @classmethod
    def create(cls, parent, name, permit):
        if type(parent) is not ParentLease:
            raise Refusal('InvalidParentLease')
        meter = consume(permit, 'create-ledger', (parent, name))
        owner = meter._owner
        _name(name)
        parent._validate(meter, owner)
        fd = _call(meter, owner, os.open, name, _FILE | os.O_CREAT | os.O_EXCL, 0o600, dir_fd=parent._chain[-1][0])
        identity = None
        try:
            st = _call(meter, owner, os.fstat, fd)
            identity = _identity(st)
            if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1 or st.st_uid != os.getuid() or stat.S_IMODE(st.st_mode) != 0o600:
                raise Refusal('LedgerIdentity', partial=True)
            _call(meter, owner, fcntl.flock, fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            result = cls(_KEY, parent, name, fd, identity)
            result._validate(meter, owner)
            parent._book._ledger = result
            return result
        except BaseException:
            permit._book.halt('LedgerCreationFailed')
            if identity is not None:
                try:
                    book = permit._book
                    if book._cleanup_left < 2:
                        raise Refusal('CleanupLimit')
                    book._cleanup_left -= 2
                    book._cleanup.charge(book, syscalls=2)
                    if _identity(os.fstat(fd)) == identity:
                        os.close(fd)
                except OSError:
                    pass
            raise

    def _validate(self, meter, owner):
        if self._closed:
            raise Refusal('LedgerClosed')
        self._parent._validate(meter, owner)
        st = _call(meter, owner, os.fstat, self._fd)
        linked = _call(meter, owner, os.stat, self.name, dir_fd=self._parent._chain[-1][0], follow_symlinks=False)
        if (_identity(st) != self._identity or _identity(linked) != self._identity or
                st.st_nlink != 1 or linked.st_nlink != 1):
            raise Refusal('LedgerIdentity', partial=True)

    def write_json(self, record, permit):
        meter = consume(permit, 'update-record', self)
        owner = meter._owner
        try:
            # Both passes and the complete bounded buffer precede the first write.
            raw = encode(record, permit)
            self._validate(meter, owner)
            offset = attempts = 0
            while offset < len(raw):
                attempts += 1
                if attempts > 256:
                    raise Refusal('WriteAttempts', partial=True)
                chunk = raw[offset:offset + 4096]
                meter.charge(owner, source_io=len(chunk))
                count = _call(meter, owner, os.pwrite, self._fd, chunk, offset)
                if type(count) is not int or not 0 < count <= len(chunk):
                    raise Refusal('ShortWrite', partial=True)
                offset += count
                self._validate(meter, owner)
            _call(meter, owner, os.ftruncate, self._fd, len(raw))
            self._validate(meter, owner)
            _call(meter, owner, os.fsync, self._fd)
            self._validate(meter, owner)
            _call(meter, owner, os.fsync, self._parent._chain[-1][0])
            self._validate(meter, owner)
            offset = requests = 0
            while offset < len(raw):
                requests += 1
                if requests > 64:
                    raise Refusal('ReadAttempts', partial=True)
                size = min(4096, len(raw) - offset)
                meter.charge(owner, source_io=size)
                part = _call(meter, owner, os.pread, self._fd, size, offset)
                if part != raw[offset:offset + size]:
                    raise Refusal('ReadbackMismatch', partial=True)
                offset += size
                self._validate(meter, owner)
            meter.charge(owner, source_io=1)
            if _call(meter, owner, os.pread, self._fd, 1, offset):
                raise Refusal('ReadbackTail', partial=True)
            self._validate(meter, owner)
            self._book._commits += 1
            return dict(bytes=len(raw), sequence=permit.record_sequence)
        except BaseException:
            self._book.halt('LedgerUpdateFailed')
            raise

    def close(self, permit):
        meter = consume(permit, 'cleanup-close', self)
        owner = meter._owner
        if self._closed or _identity(_call(meter, owner, os.fstat, self._fd)) != self._identity:
            raise Refusal('ForeignDescriptor')
        _call(meter, owner, os.close, self._fd)
        self._closed = True
