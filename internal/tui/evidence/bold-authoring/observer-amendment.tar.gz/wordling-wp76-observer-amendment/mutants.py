"""One finite WP76 semantic campaign in an exact Git-derived component closure."""
import base64
import difflib
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import time

ROOT = Path('/home/lynn/projects/wordling/.worktrees/wp51-parity-01M64CVY-lane-h')
EVIDENCE = Path(__file__).resolve().parent
BASELINE = Path('/home/lynn/projects/wordling/preview/wordling')
MUTANT = Path('/tmp/wordling-wp76-run/wordling-f6-hook-mutant')
PTY = EVIDENCE/'pty-qualified'
ENV = dict(os.environ, GOTOOLCHAIN='local', GOPROXY='off', PYTHONDONTWRITEBYTECODE='1')
SOURCE = '5e6f291712182df9b6299c0fea977ba3d7168d29'
MAX_SECONDS = 180
MODEL = 'internal/tui/model.go'
BOLD = 'internal/tui/bold_authoring.go'
PACKAGES = ('cmd/wordling','internal/tui','internal/input','internal/editor',
            'internal/document','internal/wp51','internal/storage','internal/macro/runtime','internal/macro/wpm')
HOOK = "\tif next, cmd, handled := m.boldKey(*k); handled {\n\t\treturn next, cmd\n\t}\n"
IDLE = """	if !m.boldHostIdle() {
		m.notice = "Bold requires the current idle application context"
		return m, nil, true
	}
"""
COUNT = """	if m.characterRepeat.active {
		return m.characterPress(*event.Key)
	}
"""
MUTANTS = (
    ('omit-application-hook', MODEL, HOOK, '',
     'TestBoldModelLifecycle', 'bare F6 did not open the real native span'),
    ('omit-host-idle-fence', BOLD, IDLE, '',
     'TestBoldCurrentUIAndIdleFences', 'changed authoritative Bold session'),
    ('count-enters-bold', MODEL, COUNT, """	if m.characterRepeat.active {
		if event.Key.Code == tea.KeyF6 {
			m.characterRepeat = characterRepeat{}
			return m.reduce(editor.Event{Command: editor.Bold})
		}
		return m.characterPress(*event.Key)
	}
""", 'TestBoldCharacterCountAndMenuOrdering', 'changed authoritative Bold session'),
    ('text-bearing-f6-alias', BOLD, 'k.Mod != 0 || k.Text != "" || k.IsRepeat', 'k.Mod != 0 || k.IsRepeat',
     'TestBoldMalformedKeysNeverAliasText', 'changed authoritative Bold session'),
    ('swallow-first-save-receipt', MODEL, 'return m.firstResult(v.ticket)', 'return m, nil',
     'TestBoldModelRootedSaveAndReceipts', 'actual first publication/read receipt did not settle'),
    ('state-consumes-format-authority', MODEL, 'func (m Model) State() State {',
     'func (m Model) State() State {\n\t_, _ = m.Update(tea.KeyPressMsg{Code: tea.KeyF6})',
     'TestBoldObserverAndAdministrativeRecovery', 'observation or administrative message prevented recovery'),
)



def sha(data):
    return hashlib.sha256(data).hexdigest()


def snapshot(root):
    files = []
    for p in sorted(root.rglob('*')):
        if p.is_file():
            b = p.read_bytes()
            files.append(dict(path=str(p.relative_to(root)), mode=oct(p.stat().st_mode),
                              bytes=len(b), sha256=sha(b)))
    return files


def execute():
    assert EVIDENCE == Path('/tmp/wordling-wp76-run/evidence')
    started = time.monotonic()
    records = []
    results = []
    summary = {'source': SOURCE, 'commands': records, 'mutants': results, 'limit_seconds': MAX_SECONDS}
    active = None

    def run(args, cwd, env=ENV):
        then = time.monotonic()
        remaining = MAX_SECONDS - (then - started)
        assert remaining > 0, 'campaign time exhausted'
        try:
            p = subprocess.run(args, cwd=cwd, env=env, capture_output=True, timeout=remaining)
        except subprocess.TimeoutExpired as err:
            records.append(dict(argv=args, cwd=str(cwd), timeout=remaining,
                                stdout_hex=(err.stdout or b'').hex(), stderr_hex=(err.stderr or b'').hex()))
            raise
        records.append(dict(argv=args, cwd=str(cwd), exit=p.returncode,
                            elapsed=time.monotonic()-then, stdout_hex=p.stdout.hex(), stderr_hex=p.stderr.hex()))
        return p

    try:
        revision = run(['git','rev-parse',SOURCE], ROOT)
        assert revision.returncode == 0
        summary['source'] = revision.stdout.decode().strip()
        listed = run(['git','ls-tree','-r','--name-only',summary['source'],'--',
                      *PACKAGES,'go.mod','go.sum'], ROOT)
        assert listed.returncode == 0
        paths = [p for p in listed.stdout.decode().splitlines()
                 if p in {'go.mod','go.sum'} or
                 (p.endswith('.go') and p.rsplit('/',1)[0] in PACKAGES)]
        # Archive by literal approved source paths. Focused targets create their
        # own native inputs and do not select the historical fixture suite.
        archive = run(['git','archive','--format=tar',summary['source'],'--',*paths], ROOT)
        assert archive.returncode == 0
        records[-1]['stdout_base64'] = base64.b64encode(archive.stdout).decode()
        del records[-1]['stdout_hex']
        with tempfile.TemporaryDirectory(prefix='wordling-wp76-mutant-') as scratch:
            active = Path(scratch)
            summary['scratch'] = str(active)
            with tarfile.open(fileobj=io.BytesIO(archive.stdout)) as contents:
                contents.extractall(active,filter='data')
            frozen = snapshot(active)
            assert set(paths) == {x['path'] for x in frozen}
            summary['closure'] = frozen
            tooltmp = active/'tooltmp'
            tooltmp.mkdir()
            env = dict(ENV, GOTMPDIR=str(tooltmp))
            for name, file, before, after, target, diagnostic in MUTANTS:
                path = active/file
                old = path.read_text()
                assert old.count(before) == 1, name
                changed = old.replace(before,after)
                item = dict(name=name, target=target, diagnostic=diagnostic,
                            source_sha256=sha(changed.encode()),
                            diff=''.join(difflib.unified_diff(old.splitlines(True), changed.splitlines(True),
                                                           fromfile=file,tofile=file)))
                results.append(item)
                path.write_text(changed)
                try:
                    compile_check = run(['go','test','-run','^$','./internal/tui'],active,env)
                    item['compile_exit'] = compile_check.returncode
                    assert compile_check.returncode == 0, name
                    target_check = run(['go','test','-v','-count=1','-run',f'^{target}$','./internal/tui'],active,env)
                    item['target_exit'] = target_check.returncode
                    item['intended_failure'] = target_check.returncode == 1 and diagnostic.encode() in target_check.stdout
                    assert item['intended_failure'], name
                    if name == 'omit-application-hook':
                        assert not os.path.lexists(MUTANT)
                        p = run(['go','build','-o',str(MUTANT),'./cmd/wordling'],active,env)
                        assert p.returncode==0
                        build = run(['go','version','-m',str(MUTANT)],active,env)
                        assert build.returncode==0
                        binary = MUTANT.read_bytes()
                        assert len(binary)+BASELINE.stat().st_size <= 64*1024*1024
                        bas = json.loads((EVIDENCE/'qualified-baseline-launch.json').read_text())
                        assert sha(BASELINE.read_bytes())==bas['binary_sha256']
                        receipt = dict(bas,mode='mutant',binary=str(MUTANT),
                                       binary_sha256=sha(binary),binary_bytes=len(binary),
                                       baseline_reader_passed=True,
                                       patch_sha256=sha(item['diff'].encode()),
                                       buildinfo=build.stdout.decode())
                        receipt_path = EVIDENCE/'mutant-launch.json'
                        receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
                        assert (EVIDENCE/'reader.exit').read_text().strip()=='0'
                        assert MAX_SECONDS-(time.monotonic()-started) >= 34
                        p = run([sys.executable,str(EVIDENCE/'run_pty.py'),'mutant',
                                 str(MUTANT),str(PTY),str(receipt_path)],ROOT)
                        item['pty_exit'] = p.returncode
                        assert p.returncode==0
                finally:
                    path.write_text(old)
            assert snapshot(active) == frozen
            summary['restored_exact_closure'] = True
        summary['scratch_removed'] = not active.exists()
        summary['campaign_seconds'] = time.monotonic()-started
        assert len(results) == 6 and summary['campaign_seconds'] <= MAX_SECONDS
        print(json.dumps({k:summary[k] for k in ['source','scratch_removed','campaign_seconds']}))
    finally:
        summary['elapsed'] = time.monotonic()-started
        packed = gzip.compress(json.dumps(summary, separators=(',',':')).encode(),mtime=0)
        used = sum(p.stat().st_size for p in EVIDENCE.rglob("*") if p.is_file())
        assert used+len(packed) <= 7*1024*1024
        (EVIDENCE/'mutant-campaign.json.gz').write_bytes(packed)

if __name__ == '__main__':
    execute()
